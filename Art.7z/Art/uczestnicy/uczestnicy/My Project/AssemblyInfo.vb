﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Ogólne informacje o zestawie są kontrolowane poprzez następujący 
' zestaw atrybutów. Zmień wartości tych atrybutów, aby zmodyfikować informacje
' powiązane z zestawem.

' Sprawdź wartości atrybutów zestawu

<Assembly: AssemblyTitle("uczestnicy")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("uczestnicy")>
<Assembly: AssemblyCopyright("Copyright ©  2022")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'Następujący identyfikator GUID jest identyfikatorem elementu typelib w przypadku udostępnienia tego projektu w modelu COM
<Assembly: Guid("550f078c-aaea-4b68-95bc-6a1c2b6aeb95")>

' Informacje o wersji zestawu zawierają następujące cztery wartości:
'
'      Wersja główna
'      Wersja pomocnicza
'      Numer kompilacji
'      Poprawka
'
' Możesz określić wszystkie wartości lub użyć domyślnych numerów kompilacji i poprawki
' przy użyciu symbolu „*”, tak jak pokazano poniżej:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
