﻿Module Module1
    Sub numer(x As Integer)

        Dim y As Integer = 2 * x + 3
        Console.WriteLine(y)

    End Sub

    Function osoba(imie, nazwisko)

        numer(9)

        Return $"uczestnik konferencji: {imie} {nazwisko}"



    End Function

    Sub informacja()

        Console.WriteLine("Konferencja - wdrożenie wybranych algorytmów AI ")
        Console.WriteLine($"uczesnik konferncji - {osoba("jan", "nowak")}")


    End Sub


    Sub Main()

        informacja()
        Console.ReadKey()


    End Sub

End Module
