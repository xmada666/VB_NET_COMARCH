﻿Module Module1

    Sub Main()
        Console.WriteLine("pierwszy program...")
        Dim imie = "Artur"
        Dim nazwisko As String = "Adamski"
        Dim wiek = 43
        'komentarz ctrl k+ c  odkomentowanie ctrl k + u 
        MsgBox(VarType(imie))
        MsgBox(VarType(nazwisko))
        MsgBox(VarType(wiek))


        Dim wiekD = CDbl(wiek)
        wiekD = 79.9
        MsgBox("wiek = " + wiekD.ToString)


        If imie = "jan" Then
            Console.WriteLine("cześć jan")
        End If
        If imie = "Artur" Then
            If wiekD = 79.9 Then
                Console.WriteLine("cześć Artur niedługo twoeje 80 urudziny")
            Else
                Console.WriteLine("cześć Artur nie masz urodzin")
            End If
        End If
        Console.ReadKey()
    End Sub

End Module
