﻿Module Module1

    Sub Main()

        Dim k1 As Kolor = New Kolor(34, "niebieski")

        k1.printKolor()



        Dim K2 As Kolor = New Kolor(113, "róż")

        K2.nazwa_palety = "dupa"
        K2.imie = "Adolf"
        K2.nazwisko = "znany"

        K2.printKolor()

        Console.ReadKey()





    End Sub

End Module
