﻿Public Class Kolor

    'definicja stanu

    Public imie As String
    Public nazwisko As String
    Public nazwa_koloru As String
    Public id_koloru As Integer
    Public nazwa_palety As String

    'konstruktor klasy

    Public Sub New(id_koloru As Integer, nazwa_koloru As String)

        Me.id_koloru = id_koloru
        Me.nazwa_koloru = nazwa_koloru
        Me.imie = "Artur"
        Me.nazwisko = "Kot"
        Me.nazwa_palety = "standard A"

    End Sub

    'zachowanie
    Public Function printKolor() As String

        Console.WriteLine($"id koloru: {id_koloru}, nazwa koloru: {nazwa_koloru}, paleta: {nazwa_palety},
twórca: {imie} {nazwisko}")
    End Function


End Class
