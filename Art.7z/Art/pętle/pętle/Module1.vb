﻿Module Module1

    Sub Main()
        Dim x = 0, y
        Do Until x = 11
            x = x + 1
            y = 2 * x
            Console.Write($"wartość y = {y}")
        Loop

        For n = 1 To 4
            For m = 1 To 5
                Console.WriteLine($"para (n,m: ({n},{m})")
            Next
        Next



        Console.ReadKey()
    End Sub

End Module
