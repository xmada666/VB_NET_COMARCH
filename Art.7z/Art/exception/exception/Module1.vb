﻿Module Module1

    Sub Main()

        Try
            Dim x As Integer = 0
            Dim y As Double = 1 / x
            Console.WriteLine($"wartość y = {y}")
            Console.WriteLine($"pierwiastek z  y: {Math.Sqrt(y)}")


        Catch ex As DivideByZeroException
            Console.WriteLine($"dizlenie przez 0: {ex.Message}")
            Exit Sub
        Finally
            MsgBox("kod zawsze wykonany")
        End Try


        Console.ReadKey()


    End Sub

End Module
