﻿Module Module1

    Sub Main()

        Dim dzis, datafaktury As Date
        Dim datafakruryS As String
        Dim plDni As Long 'liczba przekroczonych dni

        dzis = Now
        datafakruryS = InputBox("podaj datę wystawienia faktury ")
        'wD - liczba dni od wystawienia faktury

        Dim wD As Long

        If IsDate(datafakruryS) Then
            datafaktury = CDate(datafakruryS)

            wD = DateDiff("d", datafaktury, dzis)
            If wD > 30 Then
                plDni = wD - 30
                MsgBox("liczba dni: " & wD & Chr(13) & "przekroczono termin płatności o " _
                       & plDni & " dni, wplać niezwłocznie!")
            Else
                MsgBox("liczba dni: " & wD)
            End If

        Else
            MsgBox("to nie jest data - podaj datę")

        End If

    End Sub

End Module
