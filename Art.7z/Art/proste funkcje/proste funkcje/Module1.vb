﻿Module Module1

    Function mnozenie(a, b, c)
        mnozenie = a * b * c
    End Function

    Function policz(a, b, x)
        Return (a + b) * x
    End Function

    Sub Main()
        Dim x As Integer
        x = mnozenie(34, 2, 78)
        Console.WriteLine("wynik mnożenia = " & x)
        MsgBox("wynik mnożenia = " & x)

        MsgBox("wynik działania policz " & policz(2, 4, 6))

        Console.ReadKey()
    End Sub

End Module
