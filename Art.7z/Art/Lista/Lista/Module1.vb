﻿Module Module1

    Sub Main()
        Dim kolory As New List(Of String)
        kolory.Add("czerowny")
        kolory.Add("czarny")
        kolory.Add("biały")
        kolory.Add("żółty")


        For Each kol As String In kolory
            Console.WriteLine(kol)
        Next
        Console.WriteLine("++++++++++++++++++++++++")

        ''DODAWANIE DO LISTY Z ARRAYLISTY

        Dim kolory_ini As New List(Of String) From
            {"pomarańczowy", "liliowy", "brązowy"}


        For Each kolin As String In kolory_ini
            Console.WriteLine(kolin)
        Next
        '' USUWANIE Z LISTY
        kolory_ini.Remove("liliowy")

        For index = 0 To kolory_ini.Count - 1
            Console.Write(kolory_ini(index) & " ")
        Next




        Console.ReadKey()
    End Sub


End Module
