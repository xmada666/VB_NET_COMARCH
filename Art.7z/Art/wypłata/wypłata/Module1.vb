﻿Module Module1

    Sub Main()
        'podaj wysokość kwoty brutto do wypłaty (inputbox)
        'przelicz kwotę na kwotę do wypłaty (netto) która będzie wynosiła 73% kwoty brutto
        'wyświetl wynik w dwóch postaciach msgbox i consola
        'zastanó się jak zareagować na błędnie podaną wartość kwoty brutto

        Dim kwotaBrutto As Double
        Dim podajKwoteBrutto As String = InputBox("podaj kwotę brutto do wypłąty ")

        If IsNumeric(podajKwoteBrutto) And kwotaBrutto = CDbl(podajKwoteBrutto) > 0 Then



            kwotaBrutto = CDbl(podajKwoteBrutto)

            Dim kwotaNetto As Double

            kwotaNetto = kwotaBrutto * 0.73

            MsgBox($"kwota netto do wypłąty {kwotaNetto} ")

            Console.WriteLine($"kwota netto do wypłąty {kwotaNetto} ")

            Console.ReadKey()
        End If

        MsgBox("podaj prawidłwo kwotę")
    End Sub

End Module
