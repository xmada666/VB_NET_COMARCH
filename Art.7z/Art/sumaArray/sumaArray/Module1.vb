﻿Module Module1


    Function addElement(ParamArray arr As Integer()) As Integer
        Dim suma As Integer = 0
        Dim i As Integer = 0
        For Each i In arr
            suma = +i

        Next i

        Return suma

    Sub Main()



    End Sub

End Module

