﻿Module Module1


    'napisz funkcje która będzie zwracała datę ważności produktu kosmetycznego
    'funkcja oparta na parametrach data_otwarcia , oznaczenie 
    'wazność produktu liczy się od daty otwarcia w zależności od rodzaju oznaczenia na putelku
    'oznaczenia:
    '1m - 30 dni, 3M - 90 dni, 6M - 90 dni, 1R - 365 dni, 3L - 1095 dni

    'zaimplementuj funkcję w main -> podaj z imputbox - datę otwarcia i oznaczenie na putełku
    'wywołaj funkcję i wyświetl datę przydatności

    Function waznosc(data As Date, oznaczenie As String) As Date



        Dim dataWaznosci As Date

        If oznaczenie.ToUpper.Contains("1m") Then
            dataWaznosci = DateAdd("d", 30, data)

        End If
        If oznaczenie.ToUpper.Contains("3m") Then
            dataWaznosci = DateAdd("d", 90, data)

        End If
        Return dataWaznosci
    End Function
    Sub Main()
        Dim data As String
        Dim oznaczenie As String
        data = InputBox("podaj date")
        oznaczenie = InputBox("podaj oznaczenie")



        MsgBox($"data waznosci:{waznosc(CDate(data), oznaczenie)}")

    End Sub

End Module
