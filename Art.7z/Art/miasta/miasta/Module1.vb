﻿Module Module1

    Sub Main()
        Dim miasto As String
        Dim miasta(5) As String

        miasta(0) = "Londyn"
        miasta(1) = "Szczecin"
        miasta(2) = "Poznań"
        miasta(3) = "Warszawa"
        miasta(4) = "Moskwa"
        miasta(5) = "Kijów"

        For Each miasto In miasta
            MsgBox(miasto)

        Next
        Dim citynumS As String
        Dim citynum As Long

        citynumS = InputBox("ile miast chcesz wpisać ", "liczba miast")
        citynum = CLng(citynumS)
        Dim cities() As String

        ReDim cities(citynum)
        For i = 1 To citynum
            cities(i) = InputBox("podaj nazwę miasta")

            ''MsgBox(cities(i))
        Next

        Dim cit As String

        Dim zbior As String

        For Each cit In cities
            Console.WriteLine(cit + Chr(13))
        Next

        Console.ReadKey()




    End Sub

End Module
