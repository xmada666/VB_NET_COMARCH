﻿Module Module1
    Function funklcja_z_bledem(a, x)
        If x < 0 Then
            Return "x musi być większe lub równe 0"
            Exit Function
        End If

        If a = x Then
            Return "nieskończoność"
        Else
            Return (a * x + Math.Sqrt(x) / (a - x))
        End If
    End Function
    Sub Main()
        Dim x, a As Single
        Dim xss, ass As String
        Dim y As Object

        xss = InputBox("podaj wartość x: ", "wartość x")
        ass = InputBox("podaj wartość a: ", "wartość a")

        x = CSng(xss)
        a = CSng(ass)

        y = funklcja_z_bledem(a, x)
        Console.WriteLine($"wynnik działania funkcji :  {y}")
        Console.ReadKey()
    End Sub

End Module
