﻿Public Class Pracownik : Inherits Osoba
    Public firma As String
    Public stanowisko As String
    Public lataPracy As Integer
    Public wynagrodzenie As Double

    Public Sub New(imie As String, nazwisko As String, wiek As Integer, wzrost As Integer, waga As Double,
                   firma As String, stanowisko As String, lataPracy As Integer, wynagrodzenie As Double)
        MyBase.New(imie, nazwisko, wiek, wzrost, waga)
        Me.firma = firma
        Me.stanowisko = stanowisko
        Me.lataPracy = lataPracy
        Me.wynagrodzenie = wynagrodzenie
    End Sub

    Public Function printPracownik() As String

        Console.WriteLine($"prawownik -> firma: {firma} stanowisko {stanowisko}, lata pracy {lataPracy}, wynagrodzenie {wynagrodzenie} zł ")
    End Function

    Public Overloads Function czyPracownik() As Boolean
        Return True
    End Function
End Class
