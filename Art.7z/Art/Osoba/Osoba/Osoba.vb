﻿Public Class Osoba
    Public imie As String
    Public nazwisko As String
    Public wiek As Integer
    Public wzrost As Integer
    Public waga As Double
    Public Sub New(imie As String, nazwisko As String, wiek As Integer, wzrost As Integer, waga As Double)
        Me.imie = imie
        Me.nazwisko = nazwisko
        Me.wiek = wiek
        Me.wzrost = wzrost
        Me.waga = waga
    End Sub
    Public Function printOsoba() As String
        Console.WriteLine($"osoba - imię: {imie}, nazwisko: {nazwisko}, wiek: {wiek} lat, waga {waga} kg, wzrost: {wzrost} cm")
    End Function
    Public Function wiekZa10lat() As Integer
        Return wiek + 10
    End Function
    Public Function czyPracownik() As Boolean
        Return False
    End Function
End Class
