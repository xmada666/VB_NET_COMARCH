﻿Module Module1

    Sub Main()
        Dim os1 As Osoba = New Osoba("jan", "kowalski", 19, 205, 110)

        os1.printOsoba()
        Console.WriteLine(os1.wiekZa10lat())
        Console.WriteLine($"czy osoba jest pracownikiem?: {os1.czyPracownik()}")


        Dim per1 As Pracownik = New Pracownik("Paweł", "Jankowski", 21, 198, 98, "AVD", "inspektor", 15, 9800)

        per1.printOsoba()
        per1.printPracownik()
        Console.WriteLine(per1.czyPracownik())

        Dim st1 As Student = New Student("ola", "fajna", 21, 176, 56, 113, "guwniany", 1910, "firma konkret", "brygadzistka", 10, 6500)

        st1.printOsoba()
        st1.printPracownik()
        st1.printStudent()

        Console.ReadKey()
    End Sub

End Module
