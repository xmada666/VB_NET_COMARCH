﻿
Public Class Student : Inherits Pracownik
    Public nrStudenta As Integer
    Public kierunek As String
    Public rokStudiow As Integer

    Public Sub New(imie As String, nazwisko As String, wiek As Integer, wzrost As Integer, waga As Double,
                   nrstudenta As Integer, kierunek As String, rokstudiow As Integer,
        Optional firma As String = "", Optional stanowisko As String = "", Optional lataPracy As Integer = 0, Optional wynagrodzenie As Double = 0)
        MyBase.New(imie, nazwisko, wiek, wzrost, waga, firma, stanowisko, lataPracy, wynagrodzenie)
        Me.nrStudenta = nrstudenta
        Me.kierunek = kierunek
        Me.rokStudiow = rokstudiow



    End Sub
    Public Function printStudent() As String
        Console.WriteLine($"dane studenta {nrStudenta}, kierunek {kierunek} rok studiów {rokStudiow} ")

    End Function

    Public Overloads Function czyPracownik() As Boolean
        If firma = "" Then
            Return False
        Else
            Return True
        End If
    End Function

End Class
